package com.example.service.impl;

import com.example.dao.IItemDao;
import com.example.entity.Item;
import com.example.service.ItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ItemServiceImpl implements ItemService {

    private final IItemDao itemDao;
    @Autowired
    public ItemServiceImpl(IItemDao itemDao) {
        this.itemDao = itemDao;
    }

    @Override
    public List<Item> findExportAll(){return itemDao.findExportAll();}

    @Override
    public List<Item> findExportByItemID(String itemID) {
        try {
            itemID = "%" + itemID + "%";
            List<Item> exportList = itemDao.findExportByItemID(itemID);
            if (exportList != null) return exportList;
            else return null;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public List<Item> findClassAll() {
        return itemDao.findClassAll();
    }

    @Override
    public List<Item> findClassByItemID(String itemID) {
        try {
            itemID = "%" + itemID + "%";
            List<Item> classList = itemDao.findClassByItemID(itemID);
            if (classList != null) return classList;
            else return null;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public List<Item> findClassByClassification(String classification) {
        try {
            List<Item> classList = itemDao.findClassByClassification(classification);
            if (classList != null) return classList;
            else return null;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public List<Item> findNeedAll() {
        return itemDao.findNeedAll();
    }

    @Override
    public List<Item> findNeedByItemID(String itemID) {
        try {
            itemID = "%" + itemID + "%";
            List<Item> needList = itemDao.findNeedByItemID(itemID);
            if (needList != null) return needList;
            else return null;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public List<Item> findQuotaAll() {
        return itemDao.findQuotaAll();
    }

    @Override
    public List<Item> findQuotaByItemID(String itemID) {
        try {
            itemID = "%" + itemID + "%";
            List<Item> quotaList = itemDao.findQuotaByItemID(itemID);
            if (quotaList != null) return quotaList;
            else return null;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public List<Item> findQuotaByStrategy(String strategy) {
        try {
            List<Item> quotaList = itemDao.findQuotaByStrategy(strategy);
            if (quotaList != null) return quotaList;
            else return null;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public Item findCorrect(String itemID) {
        try {
            Item item = itemDao.findCorrect(itemID);;
            if (item != null) return item;
            else return null;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public Integer updateExport(Item item) {
        try {
            itemDao.updateExport(item);
            Integer integer = new Integer(1);
            return integer;
        } catch (Exception e) {
            System.out.println(e.toString());
            Integer integer = new Integer(0);
            return integer;
        }
    }

    @Override
    public List<Item> findAlertAll() {
            return itemDao.findAlertAll();
        }

    @Override
    public Item findStock(String itemID) {
        try {
            Item item = itemDao.findStock(itemID);;
            if (item != null) return item;
            else return null;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public Integer updateStock(Item item) {
        try {
            itemDao.updateStock(item);
            Integer integer = new Integer(1);
            return integer;
        } catch (Exception e) {
            System.out.println(e.toString());
            Integer integer = new Integer(0);
            return integer;
        }
    }
}
