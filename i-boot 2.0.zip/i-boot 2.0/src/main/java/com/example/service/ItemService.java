package com.example.service;

import com.example.entity.Item;

import java.util.List;

public interface ItemService {
    List<Item> findExportAll();
    List<Item> findExportByItemID(String itemID);
    List<Item> findClassAll();
    List<Item> findClassByItemID(String itemID);
    List<Item> findClassByClassification(String classification);
    List<Item> findNeedAll();
    List<Item> findNeedByItemID(String itemID);
    List<Item> findQuotaAll();
    List<Item> findQuotaByItemID(String itemID);
    List<Item> findQuotaByStrategy(String strategy);
    Item findCorrect(String itemID);
    Integer updateExport(Item item);
    List<Item> findAlertAll();
    Item findStock(String itemID);
    Integer updateStock(Item item);


}
