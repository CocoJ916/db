package com.example.service;

import com.example.entity.Staff;

import java.util.List;

public interface StaffService {
    boolean isStaff(String id);
    List<Staff> findStaffAll();
    List<Staff> findStaffByStaffID(String StaffID);
    Integer updateStaff(Staff staff);

}
