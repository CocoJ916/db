package com.example.service.impl;

import com.example.dao.IStaffDao;
import com.example.entity.Staff;
import com.example.service.StaffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StaffServiceImpl implements StaffService {
    private final IStaffDao staffDao;

    @Autowired
    public StaffServiceImpl(IStaffDao iStaffDao) {
        this.staffDao = iStaffDao;

        }

    @Override
    public List<Staff> findStaffAll() {
        return staffDao.findStaffAll();
    }

    @Override
    public boolean isStaff(String id) {
        try {
            List<Staff> staffList = staffDao.findStaffByStaffID(id);
            if (staffList.size() == 0) return false;
            else return true;
//            越数组
        } catch (IndexOutOfBoundsException e) {
            return false;
        }
    }

    @Override
    public List<Staff> findStaffByStaffID(String StaffID) {
        try {
            List<Staff> staffList = staffDao.findStaffByStaffID(StaffID);
            if (staffList != null)
                return staffList;
            else
                return null;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public Integer updateStaff(Staff staff) {
        try {
            int res = staffDao.updateStaff(staff);
            if (res == 0) return 0;
            else return 1;
        } catch (Exception e) {
            return 0;
        }
    }
}
