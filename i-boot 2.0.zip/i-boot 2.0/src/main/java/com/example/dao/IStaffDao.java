package com.example.dao;

import com.example.entity.Staff;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface IStaffDao {
    List<Staff> findStaffAll();
    List<Staff> findStaffByStaffID(String StaffID);
    Integer updateStaff(Staff staff);
}
