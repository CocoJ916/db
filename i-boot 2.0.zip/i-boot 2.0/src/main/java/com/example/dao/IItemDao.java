package com.example.dao;

import com.example.entity.Item;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface IItemDao {
//    通过itemID查询所有物料
    List<Item> findExportAll();
    List<Item> findExportByItemID(String itemID);
    List<Item> findClassAll();
    List<Item> findClassByItemID(String itemID);
    List<Item> findClassByClassification(String classification);
    List<Item> findNeedAll();
    List<Item> findNeedByItemID(String itemID);
    List<Item> findQuotaAll();
    List<Item> findQuotaByItemID(String itemID);
    List<Item> findQuotaByStrategy(String strategy);
    Item findCorrect(String itemID);
    Integer updateExport(Item item);
    List<Item> findAlertAll();
    Item findStock(String itemID);
    Integer updateStock(Item item);

}
