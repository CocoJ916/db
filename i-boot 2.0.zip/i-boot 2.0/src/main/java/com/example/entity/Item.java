package com.example.entity;

import lombok.Data;

@Data
public class Item {
    private String itemID;
    private String itemName;
    private int stock;
    private String price;
    private int consumption;
    private String postdate;
    private String period;
    private String fee;
    private String period_class;
    private String consumption_class;
    private String price_class;
    private String general_class;
    private double evaluation;
    private String classification;
    private String need_sequence;
    private double need_DL;
    private String strategy;
    private int order_period;
    private int order_quantity;
    private int order_point;
    private int stock_max;
    private int stock_safe;

    public String getItemID() {
        return itemID;
    }

    public void setItemID(String itemID) {
        this.itemID = itemID;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public int getConsumption() {
        return consumption;
    }

    public void setConsumption(int consumption) {
        this.consumption = consumption;
    }

    public String getPostdate() {
        return postdate;
    }

    public void setPostdate(String postdate) {
        this.postdate = postdate;
    }

    public String getPeriod() {
        return period;
    }

    public void setPeriod(String period) {
        this.period = period;
    }

    public String getFee() {
        return fee;
    }

    public void setFee(String fee) {
        this.fee = fee;
    }

    public String getPeriod_class() {
        return period_class;
    }

    public void setPeriod_class(String period_class) {
        this.period_class = period_class;
    }

    public String getConsumption_class() {
        return consumption_class;
    }

    public void setConsumption_class(String consumption_class) {
        this.consumption_class = consumption_class;
    }

    public String getPrice_class() {
        return price_class;
    }

    public void setPrice_class(String price_class) {
        this.price_class = price_class;
    }

    public String getGeneral_class() {
        return general_class;
    }

    public void setGeneral_class(String general_class) {
        this.general_class = general_class;
    }

    public double getEvaluation() {
        return evaluation;
    }

    public void setEvaluation(double evaluation) {
        this.evaluation = evaluation;
    }

    public String getClassification() {
        return classification;
    }

    public void setClassification(String classification) {
        this.classification = classification;
    }

    public String getNeed_sequence() {
        return need_sequence;
    }

    public void setNeed_sequence(String need_sequence) {
        this.need_sequence = need_sequence;
    }

    public double getNeed_DL() {
        return need_DL;
    }

    public void setNeed_DL(double need_DL) {
        this.need_DL = need_DL;
    }

    public String getStrategy() {
        return strategy;
    }

    public void setStrategy(String strategy) {
        this.strategy = strategy;
    }

    public int getOrder_period() {
        return order_period;
    }

    public void setOrder_period(int order_period) {
        this.order_period = order_period;
    }

    public int getOrder_quantity() {
        return order_quantity;
    }

    public void setOrder_quantity(int order_quantity) {
        this.order_quantity = order_quantity;
    }

    public int getOrder_point() {
        return order_point;
    }

    public void setOrder_point(int order_point) {
        this.order_point = order_point;
    }

    public int getStock_max() {
        return stock_max;
    }

    public void setStock_max(int stock_max) {
        this.stock_max = stock_max;
    }

    public int getStock_safe() {
        return stock_safe;
    }

    public void setStock_safe(int stock_safe) {
        this.stock_safe = stock_safe;
    }
}
