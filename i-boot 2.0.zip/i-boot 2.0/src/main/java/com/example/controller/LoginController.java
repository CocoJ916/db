package com.example.controller;

import com.example.entity.Staff;
import com.example.service.impl.StaffServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller

public class LoginController {
    private final StaffServiceImpl staffService;
@Autowired
    public LoginController( StaffServiceImpl staffService) {
        this.staffService = staffService;
}

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public ModelAndView index() {
        ModelAndView modelAndView = new ModelAndView("login");
        return modelAndView;
    }
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public @ResponseBody
    ModelAndView login(String userid, String password, HttpSession session,String staffName) {
        if (staffService.isStaff(userid) == true) {
            List<Staff> staffList = staffService.findStaffByStaffID(userid);
//            获取列表的第一个元素
            Staff staff=staffList.get(0);
            staffName =staff.getStaffName();
            if (staff.getPassword().equals(password)) {
                session.setAttribute("userid", userid);
                session.setAttribute("username", staffName);
                if(staff.getIfAdmin().equals("是")){
                ModelAndView modelAndView = new ModelAndView("admin/admin_index");
                return modelAndView;
                }
                else {
                    ModelAndView modelAndView = new ModelAndView("staff/staff_index");
                    return modelAndView;
                }
            } else {
                ModelAndView modelAndView = new ModelAndView("login");
                modelAndView.addObject("result", "密码错误！");
                return modelAndView;
            }

        } else {
            ModelAndView modelAndView = new ModelAndView("login");
            modelAndView.addObject("result", "用户名不存在！");
            return modelAndView;
        }
    }
}
