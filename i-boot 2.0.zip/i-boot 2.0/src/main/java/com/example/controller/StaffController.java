package com.example.controller;

import com.example.entity.Item;
import com.example.entity.Staff;
import com.example.service.impl.ItemServiceImpl;
import com.example.service.impl.StaffServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/staff")
public class StaffController {
    private final ItemServiceImpl itemService;
    private final StaffServiceImpl staffService;
    @Autowired
    public StaffController(ItemServiceImpl itemService, StaffServiceImpl staffService) {
        this.itemService = itemService;
        this.staffService = staffService;
    }
//跳转到备件出库信息
    @GetMapping("/staff_index")
    public ModelAndView staff_check_export(HttpSession session,String htmlname){
        List<Item> exportList = itemService.findExportAll();
        htmlname="备件出库信息";
        session.setAttribute("htmlname", htmlname);
        ModelAndView modelAndView = new ModelAndView("staff/staff_index");
        modelAndView.addObject("exportList", exportList);
        return modelAndView;
    }
//    查询备件出库信息
    @PostMapping("/staff_check_export_process")
    public ModelAndView staff_check_export_process(String itemID) {
        ModelAndView modelAndView = new ModelAndView("staff/staff_index");
        List<Item> exportList = itemService.findExportByItemID(itemID);
        if (exportList.size() == 0 ) {
            modelAndView.addObject("result", "查询不到物料！");
            return modelAndView;
        }
        modelAndView.addObject("exportList", exportList);
        String result = "共查询到" + exportList.size() + "条结果";
        modelAndView.addObject("result", result);
        return modelAndView;
    }
//跳转到备件分类信息
    @GetMapping("/staff_classification")
    public ModelAndView staff_classification(HttpSession session,String htmlname){
        htmlname="备件分类信息";
        session.setAttribute("htmlname", htmlname);
        ModelAndView modelAndView = new ModelAndView("staff/staff_classification");
        List<Item> classList = itemService.findClassAll();
        modelAndView.addObject("classList", classList);
        return modelAndView;
    }
//    查询备件分类信息
    @PostMapping("/staff_check_class_process")
    public ModelAndView staff_check_class_process(String itemID,String classification) {
        ModelAndView modelAndView = new ModelAndView("staff/staff_classification");
        List<Item> classList=itemService.findClassByClassification(classification);
        if (classList.size() == 0 ) {
            List<Item> class2List = itemService.findClassByItemID(itemID);
            if (class2List.size() == 0 ) {
                modelAndView.addObject("result", "查询不到物料！");
            return modelAndView;
            }
            modelAndView.addObject("classList", class2List);
            String result = "共查询到" + class2List.size() + "条结果";
            modelAndView.addObject("result", result);
            return modelAndView;
        }
        modelAndView.addObject("classList", classList);
        String result = "共查询到" + classList.size() + "条结果";
        modelAndView.addObject("result", result);
        return modelAndView;
    }
//跳转到备件需求量预测
    @GetMapping("/staff_need")
    public ModelAndView staff_need(HttpSession session,String htmlname){
        htmlname="备件需求量预测";
        session.setAttribute("htmlname", htmlname);
        ModelAndView modelAndView = new ModelAndView("staff/staff_need");
        List<Item> needList = itemService.findNeedAll();
        modelAndView.addObject("needList", needList);
        return modelAndView;
    }
//    查询备件需求量预测
    @PostMapping("/staff_check_need_process")
    public ModelAndView staff_check_need_process(String itemID) {
        ModelAndView modelAndView = new ModelAndView("staff/staff_need");
        List<Item> needList = itemService.findNeedByItemID(itemID);
        if (needList.size() == 0 ) {
            modelAndView.addObject("result", "查询不到物料！");
            return modelAndView;
        }
        modelAndView.addObject("needList", needList);
        String result = "共查询到" + needList.size() + "条结果";
        modelAndView.addObject("result", result);
        return modelAndView;
    }
//跳转到储备定额计算
    @GetMapping("/staff_quota")
    public ModelAndView staff_quota(HttpSession session,String htmlname){
        htmlname="储备定额计算";
        session.setAttribute("htmlname", htmlname);
        ModelAndView modelAndView = new ModelAndView("staff/staff_quota");
        List<Item> quotaList = itemService.findQuotaAll();
        modelAndView.addObject("quotaList", quotaList);
        return modelAndView;
    }
//    查询储备定额计算
    @PostMapping("/staff_check_quota_process")
    public ModelAndView staff_check_quota_process(String itemID,String strategy) {
        ModelAndView modelAndView = new ModelAndView("staff/staff_quota");
        List<Item> quotaList = itemService.findQuotaByStrategy(strategy);
        if (quotaList.size() == 0 ) {
            List<Item> quota2List = itemService.findQuotaByItemID(itemID);
            if (quota2List.size() == 0 ) {
                modelAndView.addObject("result", "查询不到物料！");
                return modelAndView;
            }
            modelAndView.addObject("quotaList", quota2List);
            String result = "共查询到" + quota2List.size() + "条结果";
            modelAndView.addObject("result", result);
            return modelAndView;
        }
        modelAndView.addObject("quotaList", quotaList);
        String result = "共查询到" + quotaList.size() + "条结果";
        modelAndView.addObject("result", result);
        return modelAndView;
    }

// 跳转到修改密码页面
    @GetMapping("/staff_change_password")
    public ModelAndView staff_change_password(HttpSession session,String htmlname) {
        htmlname="修改密码";
        session.setAttribute("htmlname", htmlname);
        String staffID = session.getAttribute("userid").toString();
        ModelAndView modelAndView = new ModelAndView("staff/staff_change_password");
        modelAndView.addObject("userid", staffID);
        return modelAndView;
    }
//提交新密码
    @PostMapping("/staff_change_password_process")
    public ModelAndView staff_change_password_process(HttpSession session, String old_password,
                                                String new_password, String new_password1,ModelAndView modelAndView) {
        String staffID = session.getAttribute("userid").toString();
         modelAndView = new ModelAndView("staff/staff_change_password");
        List<Staff> staffList = staffService.findStaffByStaffID(staffID);
        Staff staff = staffList.get(0);
        String password = staff.getPassword();
        if (!password.equals(old_password)) {
            modelAndView.addObject("result", "原密码输入错误！");
            return modelAndView;
        } else {
            if (new_password.equals(password)) {
                modelAndView.addObject("result", "新密码与原密码相同！");
                return modelAndView;
            }
            if (!new_password.equals(new_password1)) {
                modelAndView.addObject("result", "两次密码输入不一致！");
                return modelAndView;
            }
            Staff s = new Staff();
            s.setStaffID(staffID);
            s.setPassword(new_password);
            int res = staffService.updateStaff(s);
            if (res == 0)
                modelAndView.addObject("result", "修改失败！");
            else
                modelAndView.addObject("result", "修改成功！");
            return modelAndView;
        }
    }

}
