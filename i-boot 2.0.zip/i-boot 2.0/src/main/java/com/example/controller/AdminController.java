package com.example.controller;

import com.example.entity.Item;
import com.example.entity.Staff;
import com.example.service.impl.ItemServiceImpl;
import com.example.service.impl.StaffServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.util.*;

@Controller
@RequestMapping("/admin")
public class AdminController {
    private final ItemServiceImpl itemService;
    private final StaffServiceImpl staffService;
    @Autowired
    public AdminController( ItemServiceImpl itemService, StaffServiceImpl staffService) {
        this.itemService = itemService;
        this.staffService = staffService;
    }
//跳转到备件出库信息
    @GetMapping("/admin_index")
    public ModelAndView admin_check_export(HttpSession session,String htmlname){
        List<Item> exportList = itemService.findExportAll();
        htmlname="备件出库信息";
        session.setAttribute("htmlname", htmlname);
        ModelAndView modelAndView = new ModelAndView("admin/admin_index");
        modelAndView.addObject("exportList", exportList);
        return modelAndView;
    }
//    查询备件出库信息
    @PostMapping("/admin_check_export_process")
    public ModelAndView admin_check_export_process(String itemID) {
        ModelAndView modelAndView = new ModelAndView("admin/admin_index");
        List<Item> exportList = itemService.findExportByItemID(itemID);
        if (exportList.size() == 0 ) {
            modelAndView.addObject("result", "查询不到物料！");
            return modelAndView;
        }
        modelAndView.addObject("exportList", exportList);
        String result = "共查询到" + exportList.size() + "条结果";
        modelAndView.addObject("result", result);
        return modelAndView;
    }
//跳转到备件分类信息
    @GetMapping("/admin_classification")
    public ModelAndView admin_classification(HttpSession session,String htmlname){
        htmlname="备件分类信息";
        session.setAttribute("htmlname", htmlname);
        ModelAndView modelAndView = new ModelAndView("admin/admin_classification");
        List<Item> classList = itemService.findClassAll();
        modelAndView.addObject("classList", classList);
        return modelAndView;
    }
//    查询备件分类信息
    @PostMapping("/admin_check_class_process")
    public ModelAndView admin_check_class_process(String itemID,String classification) {
        ModelAndView modelAndView = new ModelAndView("admin/admin_classification");
        List<Item> classList=itemService.findClassByClassification(classification);
        if (classList.size() == 0 ) {
            List<Item> class2List = itemService.findClassByItemID(itemID);
            if (class2List.size() == 0 ) {
                modelAndView.addObject("result", "查询不到物料！");
            return modelAndView;
            }
            modelAndView.addObject("classList", class2List);
            String result = "共查询到" + class2List.size() + "条结果";
            modelAndView.addObject("result", result);
            return modelAndView;
        }
        modelAndView.addObject("classList", classList);
        String result = "共查询到" + classList.size() + "条结果";
        modelAndView.addObject("result", result);
        return modelAndView;
    }
//跳转到备件需求量预测
    @GetMapping("/admin_need")
    public ModelAndView admin_need(HttpSession session,String htmlname){
        htmlname="备件需求量预测";
        session.setAttribute("htmlname", htmlname);
        ModelAndView modelAndView = new ModelAndView("admin/admin_need");
        List<Item> needList = itemService.findNeedAll();
        modelAndView.addObject("needList", needList);
        return modelAndView;
    }
//    查询备件需求量预测
    @PostMapping("/admin_check_need_process")
    public ModelAndView admin_check_need_process(String itemID) {
        ModelAndView modelAndView = new ModelAndView("admin/admin_need");
        List<Item> needList = itemService.findNeedByItemID(itemID);
        if (needList.size() == 0 ) {
            modelAndView.addObject("result", "查询不到物料！");
            return modelAndView;
        }
        modelAndView.addObject("needList", needList);
        String result = "共查询到" + needList.size() + "条结果";
        modelAndView.addObject("result", result);
        return modelAndView;
    }
//跳转到储备定额计算
    @GetMapping("/admin_quota")
    public ModelAndView admin_quota(HttpSession session,String htmlname){
        htmlname="储备定额计算";
        session.setAttribute("htmlname", htmlname);
        ModelAndView modelAndView = new ModelAndView("admin/admin_quota");
        List<Item> quotaList = itemService.findQuotaAll();
        modelAndView.addObject("quotaList", quotaList);
        return modelAndView;
    }
//    查询储备定额计算
    @PostMapping("/admin_check_quota_process")
    public ModelAndView admin_check_quota_process(String itemID,String strategy) {
        ModelAndView modelAndView = new ModelAndView("admin/admin_quota");
        List<Item> quotaList = itemService.findQuotaByStrategy(strategy);
        if (quotaList.size() == 0 ) {
            List<Item> quota2List = itemService.findQuotaByItemID(itemID);
            if (quota2List.size() == 0 ) {
                modelAndView.addObject("result", "查询不到物料！");
                return modelAndView;
            }
            modelAndView.addObject("quotaList", quota2List);
            String result = "共查询到" + quota2List.size() + "条结果";
            modelAndView.addObject("result", result);
            return modelAndView;
        }
        modelAndView.addObject("quotaList", quotaList);
        String result = "共查询到" + quotaList.size() + "条结果";
        modelAndView.addObject("result", result);
        return modelAndView;
    }
//跳转到参数校正
    @GetMapping("/admin_correct")
    public ModelAndView admin_correct(HttpSession session,String htmlname){
        htmlname="参数校正";
        session.setAttribute("htmlname", htmlname);
        List<Item> exportList = itemService.findExportAll();
        ModelAndView modelAndView = new ModelAndView("admin/admin_correct");
        modelAndView.addObject("exportList", exportList);
        return modelAndView;
    }
//    查询参数校正
    @PostMapping("/admin_check_correct_process")
    public ModelAndView admin_check_correct_process(String itemID) {
        ModelAndView modelAndView = new ModelAndView("admin/admin_correct");
        List<Item> exportList = itemService.findExportByItemID(itemID);
        if (exportList.size() == 0 ) {
            modelAndView.addObject("result", "查询不到物料！");
            return modelAndView;
        }
        modelAndView.addObject("exportList", exportList);
        String result = "共查询到" + exportList.size() + "条结果";
        modelAndView.addObject("result", result);
        return modelAndView;
    }
//  跳转到修改参数页面
    @GetMapping("/admin_correct_export_process")
    public ModelAndView admin_correct_export_process(String itemID){
        ModelAndView modelAndView = new ModelAndView("admin/admin_correct_export_process");
        Item item = itemService.findCorrect(itemID);
        modelAndView.addObject("item", item);
        return modelAndView;
    }
//    提交参数
    @PostMapping("/admin_update_export")
    public ModelAndView admin_update_export(Item item,String period,String price,String fee) {
        ModelAndView modelAndView = new ModelAndView();
            int res = itemService.updateExport(item);
            if (res == 0) {
                modelAndView.addObject("result", "修改失败!");
                modelAndView.setViewName("admin/admin_correct_export_process");
            }
            else {
                modelAndView.setViewName("redirect:/admin/admin_correct");
            }
        return modelAndView;
    }
    //跳转到库存监测预警
    @GetMapping("/admin_alert")
    public ModelAndView admin_alert(HttpSession session,String htmlname){
        htmlname="库存监测预警";
        session.setAttribute("htmlname", htmlname);
        List<Item> alertList = itemService.findAlertAll();
        ModelAndView modelAndView=new ModelAndView("admin/admin_alert");
        if(alertList.size()==0){
            modelAndView.addObject("result", "无备件库存小于等于安全库存！");
        }
        modelAndView.addObject("alertList", alertList);
        return modelAndView;
    }
    //  跳转到修改库存页面
    @GetMapping("/admin_correct_stock_process")
    public ModelAndView admin_correct_stock_process(String itemID){
        ModelAndView modelAndView = new ModelAndView("admin/admin_correct_stock_process");
        Item item = itemService.findStock(itemID);
        modelAndView.addObject("item", item);
        return modelAndView;
    }
    //    提交库存
    @PostMapping("/admin_update_stock")
    public ModelAndView admin_update_stock(Item item,int stock) {
        ModelAndView modelAndView = new ModelAndView();
        int res = itemService.updateStock(item);
        if (res == 0) {
            modelAndView.addObject("result", "修改失败!");
            modelAndView.setViewName("admin/admin_correct_stock_process");
        }
        else {
            modelAndView.setViewName("redirect:/admin/admin_alert");
        }
        return modelAndView;
    }
// 跳转到修改密码页面
    @GetMapping("/admin_change_password")
    public ModelAndView admin_change_password(HttpSession session,String htmlname) {
        htmlname="修改密码";
        session.setAttribute("htmlname", htmlname);
        String staffID = session.getAttribute("userid").toString();
        ModelAndView modelAndView = new ModelAndView("admin/admin_change_password");
        modelAndView.addObject("userid", staffID);
        return modelAndView;
    }
//提交新密码
    @PostMapping("/admin_change_password_process")
    public ModelAndView admin_change_password_process(HttpSession session, String old_password,
                                                String new_password, String new_password1,ModelAndView modelAndView) {
        String staffID = session.getAttribute("userid").toString();
         modelAndView = new ModelAndView("admin/admin_change_password");
        List<Staff> staffList = staffService.findStaffByStaffID(staffID);
        Staff staff = staffList.get(0);
        String password = staff.getPassword();
        if (!password.equals(old_password)) {
            modelAndView.addObject("result", "原密码输入错误！");
            return modelAndView;
        } else {
            if (new_password.equals(password)) {
                modelAndView.addObject("result", "新密码与原密码相同！");
                return modelAndView;
            }
            if (!new_password.equals(new_password1)) {
                modelAndView.addObject("result", "两次密码输入不一致！");
                return modelAndView;
            }
            Staff s = new Staff();
            s.setStaffID(staffID);
            s.setPassword(new_password);
            int res = staffService.updateStaff(s);
            if (res == 0)
                modelAndView.addObject("result", "修改失败！");
            else
                modelAndView.addObject("result", "修改成功！");
            return modelAndView;
        }
    }

////    跳转到员工信息管理
//    @GetMapping("/admin_manage_staff")
//    public ModelAndView admin_manage_staff(HttpSession session,String htmlname){
//        htmlname="员工信息管理";
//        session.setAttribute("htmlname", htmlname);
//        List<Staff> staffList = staffService.findStaffAll();
//        ModelAndView modelAndView = new ModelAndView("admin/admin_manage_staff");
//        modelAndView.addObject("staffList", staffList);
//
//        return modelAndView;
//    }
//
////    查询用户
//    @PostMapping("/admin_check_staff")
//    public ModelAndView admin_check_staff(String staffID) {
//        List<Staff> staffList = staffService.findStaffByStaffID(staffID);
//        ModelAndView modelAndView = new ModelAndView("admin/admin_manage_staff");
//        if (staffList .size() == 0 ) {
//            modelAndView.addObject("result", "查询不到用户！");
//            return modelAndView;
//        }
//        modelAndView.addObject("staffList", staffList);
//        return modelAndView;
//    }
//
//// 跳转到修改员工信息页面
//    @GetMapping("/admin_correct_staff_process")
//    public ModelAndView admin_correct_staff_process(String staffID){
//        ModelAndView modelAndView = new ModelAndView("admin/admin_correct_staff_process");
//        List<Staff> staff= staffService.findStaffByStaffID(staffID);
//        modelAndView.addObject("staff", staff.get(0));
//        return modelAndView;
//    }
//
//    //    提交用户信息
//    @PostMapping("/admin_update_staff")
//    public ModelAndView admin_update_staff(String staffID,String staffName,String password,Staff staff) {
//        ModelAndView modelAndView = new ModelAndView();
//        List<Staff> staffList = staffService.findStaffAll();
//        for(Staff list:staffList){
//            if (staffID==list.getStaffID()){
//                modelAndView.setViewName("admin/admin_correct_staff_process");
//                modelAndView.addObject("result", "用户id已存在!");
//            }
//        }
//
//        if (staffID.equals("") || staffName.equals("") || password.equals("")) {
//            modelAndView.setViewName("admin/admin_correct_staff_process");
//            modelAndView.addObject("result", "输入值不能为空!");
//        }
//        else {
//            int res = staffService.updateStaff(staff);
//            if (res == 0) {
//                modelAndView.addObject("result", "修改失败!");
//                modelAndView.setViewName("admin/admin_correct_staff_process");
//            }
//        }
//
//                modelAndView.setViewName("redirect:/admin/admin_manage_staff");
//
//
//
//        return modelAndView;
//    }
}
