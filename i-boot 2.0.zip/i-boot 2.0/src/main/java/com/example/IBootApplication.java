package com.example;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


import javax.servlet.http.HttpSession;
import java.util.*;


@SpringBootApplication
@MapperScan(basePackages = "com.example.dao")
public class IBootApplication {

    public static void main(String[] args) {
        SpringApplication.run(IBootApplication.class, args);
    }

}
